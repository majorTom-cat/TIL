import { useState } from "react";
import DetailContent from "./body/DetailContent";
import DetailContentExplain from "./body/DetailContentExplain";
import Footer from "../Final/Footer/Footer";
import Login_header from "../Final/Header/Login";

const Detail = () => {
  const [userState, setUserState] = useState({
    isLogged: true,
    isFavorite: false,
  });

  const clickFavorite = () => {
    setUserState({
      isLogged: true,
      isFavorite: true,
    });
  };

  return (
    <>
      <Login_header userState={userState} />
      <DetailContent userState={userState} clickFavorite={clickFavorite} />
      <DetailContentExplain />
      <Footer />
    </>
  );
};

export default Detail;
