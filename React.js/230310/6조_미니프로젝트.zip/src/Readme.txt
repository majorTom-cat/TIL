1. 프로젝트 새로 생성 : yarn create react-app sence
2. cd sence
3. 소스코드 그대로 sence/src 안에 복사 붙여넣기
3. 터미널에 추가: yarn add @mui/material @emotion/react @emotion/styled @mui/icons-material react-slick slick-carousel react-router-dom react-simple-image-slider
4. yarn start

2가지 버젼이 존재합니다.

1. 로그인 하기 전
2. 로그인 한 후  ( 메인 화면 -> 우측 상단 LOGIN 클릭 -> LOGIN 화면에서 LOGIN 버튼 클릭 )

로그인 전,후에서 메인 화면과 상세 화면, 글쓰기 버튼의 기능이 다릅니다!