import React, { useState } from "react";
import "./Product_Page_Style.css";
import { Link } from "react-router-dom";
const CreatProduct = () => {
  // 상태 변수 정의
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [price, setPrice] = useState("");
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);

  // input 값 변경 시, 상태 변수 업데이트
  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };
  const handleLocationChange = (e) => {
    setLocation(e.target.value);
  };
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  const handlePriceChange = (e) => {
    setPrice(e.target.value);
  };
  const handleTextChange = (e) => {
    setText(e.target.value);
  };
  const handleAddressSelect = (e) => {
    setFile(e.target.files[0]);
  };

  // 게시글 작성 버튼 클릭 시, 작성된 게시글 정보 출력
  const handleFormSubmit = (e) => {
    e.preventDefault();
    console.log(title, location, price, text, file);
    // 게시글 작성 로직
  };

  return (
    <div className="container">
      <h1 className="h1">게시글 작성하기</h1>
      <form className="form" onSubmit={handleFormSubmit}>
        <div>
          <label htmlFor="title">제목</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={handleTitleChange}
          />
        </div>
        <div className="location-wrapper">
          <label htmlFor="location">거래 지역</label>
          <button type="button" onClick={handleAddressSelect}>
            주소 선택
          </button>
          <input
            type="text"
            id="location"
            value={location}
            onChange={handleLocationChange}
          />
        </div>
        <div className="fileup">
          <label htmlFor="file">파일 업로드</label>
          <input type="file" id="file" onChange={handleFileChange} />
          <div className="priceup">
            <label htmlFor="price">상품 가격</label>
            <input
              className="place"
              type="text"
              id="price"
              value={price}
              onChange={handlePriceChange}
              placeholder="원"
            />
          </div>
        </div>
        <div>
          <label htmlFor="text">상세 설명</label>
          <textarea
            id="text"
            value={text}
            onChange={handleTextChange}
            placeholder="상품 소개"
          />
        </div>
        <div className="button-container">
          <div id="loginAlert" onClick={() => alert("작성이 완료되었습니다!")}>
            <Link to="/home" style={{ textDecoration: "none" }}>
              <button type="submit" className="modify-button">
                확인
              </button>
            </Link>
          </div>
          <div id="loginAlert" onClick={() => alert("작성이 취소되었습니다!")}>
            <Link to="/home" style={{ textDecoration: "none" }}>
              <button type="button" className="cancel-button">
                취소
              </button>
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
};

export default CreatProduct;
