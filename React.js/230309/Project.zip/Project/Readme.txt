1. 프로젝트 새로 생성 : yarn create react-app sence
2. 터미널에 추가: yarn add @mui/material @emotion/react @emotion/styled @mui/icons-material react-slick slick-carousel
3. yarn start

